import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import jwt from '@fastify/jwt';
import rateLimit from '@fastify/rate-limit';

import env from './config/env.js';
import logger from './utils/logger.js';

// Routes
import healthRoutes from './routes/health.js';
import webhookRoutes from './routes/webhook.js';
import authRoutes from './routes/auth.js';

// Workers (inicializa ao importar)
import './queues/workers/message-worker.js';

// =============================================
// Inicializa Fastify
// =============================================
const fastify = Fastify({
  logger: false, // usando pino customizado
  trustProxy: true,
});

// =============================================
// Plugins
// =============================================
await fastify.register(cors, {
  origin: env.nodeEnv === 'development' ? true : [
    /centraldetintas\.com$/,
    /localhost/,
  ],
  credentials: true,
});

await fastify.register(helmet, {
  contentSecurityPolicy: false,
});

await fastify.register(jwt, {
  secret: env.jwtSecret,
});

await fastify.register(rateLimit, {
  max: env.rateLimit.max,
  timeWindow: env.rateLimit.window,
  // Webhook da Z-API não tem rate limit
  allowList: (request) => {
    return request.url.startsWith('/webhook');
  },
});

// =============================================
// Rotas
// =============================================
await fastify.register(healthRoutes);
await fastify.register(webhookRoutes);
await fastify.register(authRoutes);

// =============================================
// Error handler global
// =============================================
fastify.setErrorHandler((error, request, reply) => {
  logger.error({
    error: error.message,
    stack: error.stack,
    url: request.url,
    method: request.method,
  }, 'Erro não tratado');

  reply.code(error.statusCode || 500).send({
    error: env.nodeEnv === 'development' ? error.message : 'Erro interno',
  });
});

// =============================================
// Start
// =============================================
try {
  await fastify.listen({ port: env.port, host: '0.0.0.0' });

  logger.info(`
╔══════════════════════════════════════════════╗
║   Central de Tintas — CRM Conversacional     ║
║──────────────────────────────────────────────║
║   🚀 Server:    http://localhost:${env.port}        ║
║   📡 Webhook:   /webhook/zapi                ║
║   🔐 Auth:      /auth/login                  ║
║   💚 Health:    /health                       ║
║   🌍 Ambiente:  ${env.nodeEnv.padEnd(26)}  ║
╚══════════════════════════════════════════════╝
  `);
} catch (err) {
  logger.error(err, 'Erro ao iniciar servidor');
  process.exit(1);
}
