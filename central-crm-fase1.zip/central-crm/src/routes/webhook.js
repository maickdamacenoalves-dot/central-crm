import { messageQueue } from '../queues/setup.js';
import logger from '../utils/logger.js';

/**
 * Webhook da Z-API
 *
 * Recebe todas as mensagens do WhatsApp e enfileira para processamento.
 * Responde 200 imediatamente para não bloquear a Z-API.
 *
 * Eventos da Z-API:
 * - ReceivedCallback: mensagem recebida
 * - MessageStatusCallback: status de envio
 * - DeliveryCallback: confirmação de entrega
 * - DisconnectedCallback: desconexão do WhatsApp
 */
export default async function webhookRoutes(fastify) {

  // =============================================
  // POST /webhook/zapi - Recebe mensagens
  // =============================================
  fastify.post('/webhook/zapi', async (request, reply) => {
    const payload = request.body;

    // Z-API envia diferentes tipos de callback
    // Filtramos apenas mensagens recebidas (não enviadas por nós)
    if (payload.isFromMe || payload.fromMe) {
      return reply.code(200).send({ status: 'ignored', reason: 'from_me' });
    }

    // Ignora mensagens de grupo
    if (payload.isGroup || payload.chatIsGroup) {
      return reply.code(200).send({ status: 'ignored', reason: 'group' });
    }

    // Ignora status/stories
    if (payload.isStatusReply || payload.status) {
      return reply.code(200).send({ status: 'ignored', reason: 'status' });
    }

    // Valida se tem telefone
    const phone = payload.phone || payload.chatId?.replace('@c.us', '');
    if (!phone) {
      logger.warn('Webhook recebido sem telefone');
      return reply.code(200).send({ status: 'ignored', reason: 'no_phone' });
    }

    // Normaliza telefone no payload
    payload.phone = phone.replace(/\D/g, '');

    logger.info({
      phone: payload.phone,
      type: payload.type || 'text',
      messageId: payload.messageId,
    }, '📩 Webhook Z-API recebido');

    // Enfileira para processamento assíncrono
    await messageQueue.add(
      'incoming-message',
      {
        payload,
        channel: 'WHATSAPP',
        receivedAt: new Date().toISOString(),
      },
      {
        priority: 1,
        jobId: `zapi-${payload.messageId || Date.now()}`,
      }
    );

    // Responde 200 imediatamente
    return reply.code(200).send({ status: 'queued' });
  });

  // =============================================
  // POST /webhook/zapi/status - Status de mensagens
  // =============================================
  fastify.post('/webhook/zapi/status', async (request, reply) => {
    const { messageId, status, phone } = request.body;

    logger.debug({
      messageId,
      status, // SENT, DELIVERED, READ
      phone,
    }, '📬 Status de mensagem Z-API');

    // TODO: Atualizar status da mensagem no banco
    // e notificar painel do atendente via Socket.IO

    return reply.code(200).send({ status: 'ok' });
  });

  // =============================================
  // POST /webhook/webchat - Mensagens do webchat
  // =============================================
  fastify.post('/webhook/webchat', async (request, reply) => {
    const payload = request.body;

    if (!payload.sessionId && !payload.phone) {
      return reply.code(400).send({ error: 'sessionId ou phone obrigatório' });
    }

    logger.info({
      sessionId: payload.sessionId,
      name: payload.name,
    }, '🌐 Webhook Webchat recebido');

    await messageQueue.add(
      'incoming-message',
      {
        payload,
        channel: 'WEBCHAT',
        receivedAt: new Date().toISOString(),
      },
      { priority: 2 }
    );

    return reply.code(200).send({ status: 'queued' });
  });

  // =============================================
  // GET /webhook/health - Verifica se webhook está ativo
  // =============================================
  fastify.get('/webhook/health', async () => {
    return { status: 'ok', timestamp: new Date().toISOString() };
  });
}
