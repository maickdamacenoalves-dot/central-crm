import bcrypt from 'bcryptjs';
import prisma from '../config/database.js';
import { authenticate } from '../middleware/auth.js';
import logger from '../utils/logger.js';

export default async function authRoutes(fastify) {

  // =============================================
  // POST /auth/login
  // =============================================
  fastify.post('/auth/login', {
    schema: {
      body: {
        type: 'object',
        required: ['email', 'password'],
        properties: {
          email: { type: 'string', format: 'email' },
          password: { type: 'string', minLength: 6 },
        },
      },
    },
  }, async (request, reply) => {
    const { email, password } = request.body;

    // Busca atendente
    const agent = await prisma.agent.findUnique({
      where: { email },
      include: { store: true },
    });

    if (!agent) {
      return reply.code(401).send({ error: 'Email ou senha incorretos' });
    }

    // Verifica senha
    const validPassword = await bcrypt.compare(password, agent.passwordHash);
    if (!validPassword) {
      return reply.code(401).send({ error: 'Email ou senha incorretos' });
    }

    // Gera tokens
    const tokenPayload = {
      id: agent.id,
      email: agent.email,
      name: agent.name,
      role: agent.role,
      storeId: agent.storeId,
      storeName: agent.store.name,
    };

    const accessToken = fastify.jwt.sign(tokenPayload, { expiresIn: '15m' });
    const refreshToken = fastify.jwt.sign(
      { id: agent.id, type: 'refresh' },
      { expiresIn: '7d' }
    );

    // Atualiza último login e status
    await prisma.agent.update({
      where: { id: agent.id },
      data: {
        lastLoginAt: new Date(),
        status: 'ONLINE',
      },
    });

    logger.info({ agentId: agent.id, email }, 'Login realizado');

    return {
      accessToken,
      refreshToken,
      agent: {
        id: agent.id,
        name: agent.name,
        email: agent.email,
        role: agent.role,
        store: {
          id: agent.store.id,
          name: agent.store.name,
        },
      },
    };
  });

  // =============================================
  // POST /auth/refresh
  // =============================================
  fastify.post('/auth/refresh', async (request, reply) => {
    const { refreshToken } = request.body || {};
    if (!refreshToken) {
      return reply.code(400).send({ error: 'Refresh token obrigatório' });
    }

    try {
      const decoded = fastify.jwt.verify(refreshToken);
      if (decoded.type !== 'refresh') {
        return reply.code(401).send({ error: 'Token inválido' });
      }

      const agent = await prisma.agent.findUnique({
        where: { id: decoded.id },
        include: { store: true },
      });

      if (!agent) {
        return reply.code(401).send({ error: 'Agente não encontrado' });
      }

      const tokenPayload = {
        id: agent.id,
        email: agent.email,
        name: agent.name,
        role: agent.role,
        storeId: agent.storeId,
        storeName: agent.store.name,
      };

      const newAccessToken = fastify.jwt.sign(tokenPayload, { expiresIn: '15m' });
      const newRefreshToken = fastify.jwt.sign(
        { id: agent.id, type: 'refresh' },
        { expiresIn: '7d' }
      );

      return { accessToken: newAccessToken, refreshToken: newRefreshToken };
    } catch {
      return reply.code(401).send({ error: 'Refresh token expirado' });
    }
  });

  // =============================================
  // GET /auth/me - Perfil do atendente logado
  // =============================================
  fastify.get('/auth/me', {
    preHandler: [authenticate],
  }, async (request) => {
    const agent = await prisma.agent.findUnique({
      where: { id: request.agent.id },
      include: { store: true },
      omit: { passwordHash: true, totpSecret: true },
    });
    return agent;
  });

  // =============================================
  // POST /auth/logout
  // =============================================
  fastify.post('/auth/logout', {
    preHandler: [authenticate],
  }, async (request) => {
    await prisma.agent.update({
      where: { id: request.agent.id },
      data: { status: 'OFFLINE' },
    });
    logger.info({ agentId: request.agent.id }, 'Logout realizado');
    return { status: 'ok' };
  });
}
