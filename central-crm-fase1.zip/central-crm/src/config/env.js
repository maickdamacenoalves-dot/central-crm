const env = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT || '3333'),
  apiUrl: process.env.API_URL || 'http://localhost:3333',

  // JWT
  jwtSecret: process.env.JWT_SECRET || 'dev-secret',
  jwtRefreshSecret: process.env.JWT_REFRESH_SECRET || 'dev-refresh-secret',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '15m',
  jwtRefreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',

  // Redis
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: parseInt(process.env.REDIS_PORT || '6379'),
    password: process.env.REDIS_PASSWORD || 'redis123',
  },

  // Z-API
  zapi: {
    instanceId: process.env.ZAPI_INSTANCE_ID || '',
    instanceToken: process.env.ZAPI_INSTANCE_TOKEN || '',
    clientToken: process.env.ZAPI_CLIENT_TOKEN || '',
    baseUrl: process.env.ZAPI_BASE_URL || 'https://api.z-api.io',
  },

  // Claude AI
  anthropic: {
    apiKey: process.env.ANTHROPIC_API_KEY || '',
    model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-20250514',
  },

  // VHSYS
  vhsys: {
    accessToken: process.env.VHSYS_ACCESS_TOKEN || '',
    secretToken: process.env.VHSYS_SECRET_TOKEN || '',
    baseUrl: process.env.VHSYS_BASE_URL || 'https://api.vhsys.com/v2',
  },

  // Criptografia
  encryptionKey: process.env.ENCRYPTION_KEY || 'dev-key-32-chars-here-replace!!',

  // Rate Limiting
  rateLimit: {
    max: parseInt(process.env.RATE_LIMIT_MAX || '100'),
    window: parseInt(process.env.RATE_LIMIT_WINDOW || '60000'),
  },
};

export default env;
