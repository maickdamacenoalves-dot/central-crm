import { createCipheriv, createDecipheriv, randomBytes, scryptSync } from 'crypto';
import env from '../config/env.js';

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;
const SALT = 'central-crm-salt';

/**
 * Deriva chave de 32 bytes a partir da encryption key
 */
function deriveKey() {
  return scryptSync(env.encryptionKey, SALT, 32);
}

/**
 * Criptografa texto com AES-256-GCM
 *
 * Retorna: iv:authTag:ciphertext (hex)
 */
export function encrypt(text) {
  if (!text) return null;

  const key = deriveKey();
  const iv = randomBytes(IV_LENGTH);
  const cipher = createCipheriv(ALGORITHM, key, iv);

  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');

  const authTag = cipher.getAuthTag().toString('hex');

  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

/**
 * Descriptografa texto
 *
 * Espera formato: iv:authTag:ciphertext (hex)
 */
export function decrypt(encryptedText) {
  if (!encryptedText) return null;

  const parts = encryptedText.split(':');
  if (parts.length !== 3) return encryptedText; // texto não criptografado

  const [ivHex, authTagHex, ciphertext] = parts;

  const key = deriveKey();
  const iv = Buffer.from(ivHex, 'hex');
  const authTag = Buffer.from(authTagHex, 'hex');

  const decipher = createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(authTag);

  let decrypted = decipher.update(ciphertext, 'hex', 'utf8');
  decrypted += decipher.final('utf8');

  return decrypted;
}

/**
 * Gera hash seguro para tokens e IDs
 */
export function generateToken(length = 32) {
  return randomBytes(length).toString('hex');
}

export default { encrypt, decrypt, generateToken };
