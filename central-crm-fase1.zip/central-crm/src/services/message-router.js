import logger from '../utils/logger.js';
import session from './session.js';
import { sendQueue } from '../queues/setup.js';

/**
 * MESSAGE ROUTER
 *
 * Fluxo principal de roteamento:
 *
 * 1. Mensagem chega do webhook (Z-API)
 * 2. Normaliza formato
 * 3. Identifica contato pelo telefone
 * 4. Verifica carteirização:
 *    → SIM: rota direta para atendente vinculado (fast path)
 *    → NÃO: entra no fluxo de IA (boas-vindas)
 * 5. Busca ou cria conversa
 * 6. Salva mensagem
 * 7. Retorna decisão de roteamento
 */

/**
 * Normaliza mensagem recebida de diferentes canais
 */
export function normalizeMessage(rawPayload, channel = 'WHATSAPP') {
  if (channel === 'WHATSAPP') {
    return normalizeZapiMessage(rawPayload);
  }
  // Webchat - formato próprio
  return normalizeWebchatMessage(rawPayload);
}

/**
 * Normaliza payload da Z-API
 */
function normalizeZapiMessage(payload) {
  const { phone, senderName, messageId, text, image, audio, video, document: doc, sticker, contactMessage, locationMessage, listResponseMessage, buttonsResponseMessage } = payload;

  // Determina tipo e conteúdo
  let type = 'TEXT';
  let content = text?.message || '';
  let hasMedia = false;
  let metadata = {};

  if (image) {
    type = 'IMAGE';
    content = image.caption || '';
    hasMedia = true;
    metadata = { mediaUrl: image.imageUrl, mimetype: image.mimetype };
  } else if (audio) {
    type = 'AUDIO';
    hasMedia = true;
    metadata = { mediaUrl: audio.audioUrl, mimetype: audio.mimetype };
  } else if (video) {
    type = 'VIDEO';
    content = video.caption || '';
    hasMedia = true;
    metadata = { mediaUrl: video.videoUrl, mimetype: video.mimetype };
  } else if (doc) {
    type = 'DOCUMENT';
    hasMedia = true;
    metadata = { mediaUrl: doc.documentUrl, fileName: doc.fileName, mimetype: doc.mimetype };
  } else if (sticker) {
    type = 'STICKER';
    hasMedia = true;
    metadata = { mediaUrl: sticker.stickerUrl };
  } else if (contactMessage) {
    type = 'CONTACT_CARD';
    metadata = { vcard: contactMessage };
  } else if (locationMessage) {
    type = 'LOCATION';
    metadata = { lat: locationMessage.lat, lng: locationMessage.lng };
  } else if (buttonsResponseMessage) {
    type = 'BUTTON_RESPONSE';
    content = buttonsResponseMessage.selectedButtonId || '';
    metadata = { buttonText: buttonsResponseMessage.title };
  } else if (listResponseMessage) {
    type = 'BUTTON_RESPONSE';
    content = listResponseMessage.listResponse?.selectedRowId || '';
    metadata = { buttonText: listResponseMessage.listResponse?.title };
  }

  return {
    phone: phone?.replace(/\D/g, ''),
    senderName: senderName || null,
    externalMessageId: messageId || null,
    type,
    content,
    hasMedia,
    metadata,
    channel: 'WHATSAPP',
    raw: payload,
  };
}

/**
 * Normaliza payload do webchat
 */
function normalizeWebchatMessage(payload) {
  return {
    phone: payload.sessionId || payload.phone,
    senderName: payload.name || null,
    externalMessageId: payload.id || null,
    type: 'TEXT',
    content: payload.message || '',
    hasMedia: false,
    metadata: {},
    channel: 'WEBCHAT',
    raw: payload,
  };
}

/**
 * Roteia mensagem - decisão principal
 *
 * Retorna:
 * {
 *   route: 'BOT' | 'AGENT' | 'QUEUE',
 *   contact,
 *   conversation,
 *   message (saved),
 *   context: { isNew, isCarteirizado, assignedAgent, assignedStore }
 * }
 */
export async function routeMessage(normalizedMsg) {
  const { phone, senderName, type, content, hasMedia, metadata, channel, externalMessageId } = normalizedMsg;

  // 1. Identificar contato
  const contact = await session.findOrCreateContact(phone, senderName);
  const isNew = !contact.isCarteirizado;
  const isCarteirizado = contact.isCarteirizado && contact.assignedStoreId && contact.assignedAgentId;

  logger.info({
    phone,
    contactId: contact.id,
    isCarteirizado,
    name: contact.name,
  }, 'Contato identificado');

  // 2. Buscar conversa ativa ou criar nova
  let conversation = await session.getActiveConversation(contact.id);
  let isNewConversation = false;

  if (!conversation) {
    conversation = await session.createConversation(contact.id, channel);
    isNewConversation = true;
  }

  // 3. Salvar mensagem recebida
  const savedMessage = await session.saveMessage(conversation.id, {
    senderType: 'CONTACT',
    content,
    type,
    hasMedia,
    zapiMessageId: externalMessageId,
    metadata,
  });

  // 4. Decidir rota
  let route = 'BOT';

  if (isCarteirizado && !isNewConversation && conversation.status === 'ACTIVE') {
    // Cliente carteirizado com conversa ativa → direto pro atendente
    route = 'AGENT';
  } else if (isCarteirizado && isNewConversation) {
    // Cliente carteirizado, nova conversa → tenta atendente vinculado
    const agent = contact.assignedAgent;
    if (agent && agent.status === 'ONLINE') {
      // Atendente online → atribuir direto
      route = 'AGENT';
      await assignConversation(conversation.id, contact.assignedStoreId, contact.assignedAgentId);
    } else {
      // Atendente offline → fila da loja
      route = 'QUEUE';
      await queueConversation(conversation.id, contact.assignedStoreId);
    }
  }
  // else: novo cliente → BOT (default)

  // 5. Cache da sessão no Redis
  await session.cacheSession(phone, {
    contactId: contact.id,
    conversationId: conversation.id,
    route,
    storeId: contact.assignedStoreId,
    agentId: contact.assignedAgentId,
    isCarteirizado,
  });

  logger.info({
    conversationId: conversation.id,
    route,
    isCarteirizado,
    messageType: type,
  }, `Mensagem roteada → ${route}`);

  return {
    route,
    contact,
    conversation,
    message: savedMessage,
    context: {
      isNew,
      isNewConversation,
      isCarteirizado,
      assignedAgent: contact.assignedAgent,
      assignedStore: contact.assignedStore,
    },
  };
}

/**
 * Atribui conversa a um atendente específico
 */
async function assignConversation(conversationId, storeId, agentId) {
  const { default: prisma } = await import('../config/database.js');
  await prisma.conversation.update({
    where: { id: conversationId },
    data: {
      storeId,
      agentId,
      status: 'ACTIVE',
    },
  });
  logger.info({ conversationId, storeId, agentId }, 'Conversa atribuída ao atendente');
}

/**
 * Coloca conversa na fila da loja
 */
async function queueConversation(conversationId, storeId) {
  const { default: prisma } = await import('../config/database.js');
  await prisma.conversation.update({
    where: { id: conversationId },
    data: {
      storeId,
      status: 'WAITING',
    },
  });

  // Notifica via queue que há conversa esperando
  await sendQueue.add('notify-store-queue', {
    conversationId,
    storeId,
  });

  logger.info({ conversationId, storeId }, 'Conversa na fila da loja');
}

export default { normalizeMessage, routeMessage };
