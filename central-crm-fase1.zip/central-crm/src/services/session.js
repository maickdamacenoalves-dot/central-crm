import prisma from '../config/database.js';
import redis from '../config/redis.js';
import logger from '../utils/logger.js';

const SESSION_TTL = 60 * 60 * 24; // 24h em segundos
const ORG_ID = process.env.DEFAULT_ORG_ID || 'org-central-tintas';

/**
 * Busca ou cria um contato pelo telefone
 */
export async function findOrCreateContact(phone, name = null) {
  let contact = await prisma.contact.findUnique({
    where: { orgId_phone: { orgId: ORG_ID, phone } },
    include: {
      assignedStore: true,
      assignedAgent: true,
    },
  });

  if (!contact) {
    contact = await prisma.contact.create({
      data: {
        orgId: ORG_ID,
        phone,
        name,
        firstContactAt: new Date(),
      },
      include: {
        assignedStore: true,
        assignedAgent: true,
      },
    });
    logger.info({ phone }, 'Novo contato criado');
  }

  // Atualiza último contato
  await prisma.contact.update({
    where: { id: contact.id },
    data: { lastContactAt: new Date() },
  });

  return contact;
}

/**
 * Busca conversa ativa para o contato
 */
export async function getActiveConversation(contactId) {
  return prisma.conversation.findFirst({
    where: {
      contactId,
      status: { in: ['BOT', 'WAITING', 'ACTIVE'] },
    },
    include: {
      agent: true,
      store: true,
      messages: {
        orderBy: { createdAt: 'desc' },
        take: 20,
      },
    },
    orderBy: { createdAt: 'desc' },
  });
}

/**
 * Cria nova conversa
 */
export async function createConversation(contactId, channel = 'WHATSAPP') {
  const protocol = `CT-${Date.now().toString(36).toUpperCase()}`;

  const conversation = await prisma.conversation.create({
    data: {
      orgId: ORG_ID,
      contactId,
      channel,
      status: 'BOT',
      protocol,
    },
    include: {
      contact: true,
    },
  });

  logger.info({ conversationId: conversation.id, protocol }, 'Nova conversa criada');
  return conversation;
}

/**
 * Salva mensagem na conversa
 */
export async function saveMessage(conversationId, { senderType, senderId, content, type = 'TEXT', hasMedia = false, zapiMessageId = null, metadata = {} }) {
  return prisma.message.create({
    data: {
      conversationId,
      senderType,
      senderId,
      content,
      type,
      hasMedia,
      zapiMessageId,
      metadata,
    },
  });
}

/**
 * Armazena sessão no Redis (para lookup rápido)
 */
export async function cacheSession(phone, sessionData) {
  await redis.set(
    `session:${phone}`,
    JSON.stringify(sessionData),
    'EX',
    SESSION_TTL
  );
}

/**
 * Busca sessão no Redis
 */
export async function getCachedSession(phone) {
  const data = await redis.get(`session:${phone}`);
  return data ? JSON.parse(data) : null;
}

export default {
  findOrCreateContact,
  getActiveConversation,
  createConversation,
  saveMessage,
  cacheSession,
  getCachedSession,
};
