import env from '../config/env.js';
import logger from '../utils/logger.js';

const { zapi } = env;

/**
 * Monta a URL base da Z-API
 */
function baseUrl() {
  return `${zapi.baseUrl}/instances/${zapi.instanceId}/token/${zapi.instanceToken}`;
}

/**
 * Headers padrão da Z-API
 */
function headers() {
  return {
    'Content-Type': 'application/json',
    'Client-Token': zapi.clientToken,
  };
}

/**
 * Faz requisição à Z-API
 */
async function zapiRequest(endpoint, body) {
  const url = `${baseUrl()}/${endpoint}`;
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) {
      logger.error({ endpoint, status: res.status, data }, 'Z-API erro');
    }
    return data;
  } catch (err) {
    logger.error({ endpoint, error: err.message }, 'Z-API falha de conexão');
    throw err;
  }
}

// =============================================
// ENVIO DE MENSAGENS
// =============================================

/**
 * Envia mensagem de texto
 */
export async function sendText(phone, message) {
  return zapiRequest('send-text', { phone, message });
}

/**
 * Envia imagem
 */
export async function sendImage(phone, imageUrl, caption = '') {
  return zapiRequest('send-image', { phone, image: imageUrl, caption });
}

/**
 * Envia documento/arquivo
 */
export async function sendDocument(phone, documentUrl, fileName) {
  return zapiRequest('send-document', {
    phone,
    document: documentUrl,
    fileName,
  });
}

/**
 * Envia áudio
 */
export async function sendAudio(phone, audioUrl) {
  return zapiRequest('send-audio', { phone, audio: audioUrl });
}

/**
 * Envia botões interativos (seleção de loja, ações, etc.)
 */
export async function sendButtons(phone, message, buttons) {
  return zapiRequest('send-button-list', {
    phone,
    message,
    buttonList: {
      buttons: buttons.map((btn) => ({
        id: btn.id,
        label: btn.label,
      })),
    },
  });
}

/**
 * Envia lista interativa (select menu)
 */
export async function sendList(phone, message, buttonLabel, sections) {
  return zapiRequest('send-option-list', {
    phone,
    optionList: {
      title: message,
      buttonLabel,
      options: sections,
    },
  });
}

/**
 * Envia botões de seleção de loja
 */
export async function sendStoreSelection(phone, stores) {
  const message =
    'Para qual loja você gostaria de ser atendido? Selecione abaixo:';
  const buttons = stores.map((store) => ({
    id: `store_${store.id}`,
    label: store.name,
  }));
  return sendButtons(phone, message, buttons);
}

export default {
  sendText,
  sendImage,
  sendDocument,
  sendAudio,
  sendButtons,
  sendList,
  sendStoreSelection,
};
