import logger from '../utils/logger.js';

/**
 * Middleware de autenticação JWT
 *
 * Verifica o token no header Authorization: Bearer <token>
 * e injeta o agent autenticado no request
 */
export async function authenticate(request, reply) {
  try {
    const decoded = await request.jwtVerify();
    request.agent = decoded;
  } catch (err) {
    logger.warn({ error: err.message, ip: request.ip }, 'Auth falhou');
    return reply.code(401).send({ error: 'Token inválido ou expirado' });
  }
}

/**
 * Middleware de autorização por role
 *
 * Uso: { preHandler: [authenticate, authorize('ADMIN', 'SUPER_ADMIN')] }
 */
export function authorize(...roles) {
  return async (request, reply) => {
    if (!request.agent) {
      return reply.code(401).send({ error: 'Não autenticado' });
    }
    if (!roles.includes(request.agent.role)) {
      logger.warn({
        agentId: request.agent.id,
        role: request.agent.role,
        required: roles,
      }, 'Acesso negado');
      return reply.code(403).send({ error: 'Sem permissão para esta ação' });
    }
  };
}

export default { authenticate, authorize };
