import { Worker } from 'bullmq';
import { connection } from '../setup.js';
import messageRouter from '../../services/message-router.js';
import logger from '../../utils/logger.js';

/**
 * Worker que processa mensagens recebidas
 *
 * Jobs chegam da fila 'messages' com o payload bruto do webhook.
 * O worker normaliza, roteia e despacha para o handler correto.
 */
const messageWorker = new Worker(
  'messages',
  async (job) => {
    const { payload, channel } = job.data;

    try {
      // 1. Normaliza a mensagem
      const normalized = messageRouter.normalizeMessage(payload, channel);

      if (!normalized.phone) {
        logger.warn({ jobId: job.id }, 'Mensagem sem telefone — ignorando');
        return { status: 'skipped', reason: 'no_phone' };
      }

      // 2. Roteia
      const result = await messageRouter.routeMessage(normalized);

      // 3. Despacha para o handler correto
      switch (result.route) {
        case 'BOT':
          // Fase 2: aqui entra o Claude AI
          logger.info({
            conversationId: result.conversation.id,
            phone: normalized.phone,
          }, '🤖 Rota: BOT — aguardando implementação IA (Fase 2)');
          // TODO: aiHandler.process(result)
          break;

        case 'AGENT':
          // Fase 3: notifica o painel do atendente via Socket.IO
          logger.info({
            conversationId: result.conversation.id,
            agentId: result.context.assignedAgent?.id,
            phone: normalized.phone,
          }, '👤 Rota: AGENT — mensagem encaminhada ao atendente');
          // TODO: socketIO.emit(agentId, newMessage)
          break;

        case 'QUEUE':
          logger.info({
            conversationId: result.conversation.id,
            storeId: result.context.assignedStore?.id,
            phone: normalized.phone,
          }, '📋 Rota: QUEUE — conversa na fila da loja');
          // TODO: notificar atendentes da loja
          break;
      }

      return {
        status: 'processed',
        route: result.route,
        conversationId: result.conversation.id,
        contactId: result.contact.id,
      };
    } catch (err) {
      logger.error({ error: err.message, jobId: job.id }, 'Erro ao processar mensagem');
      throw err; // BullMQ vai fazer retry
    }
  },
  {
    connection,
    concurrency: 5,
    limiter: {
      max: 50,
      duration: 1000,
    },
  }
);

messageWorker.on('completed', (job, result) => {
  logger.debug({ jobId: job.id, result }, 'Job concluído');
});

messageWorker.on('failed', (job, err) => {
  logger.error({ jobId: job?.id, error: err.message }, 'Job falhou');
});

export default messageWorker;
