import { Queue } from 'bullmq';
import env from '../config/env.js';

const connection = {
  host: env.redis.host,
  port: env.redis.port,
  password: env.redis.password,
};

// Fila principal de mensagens recebidas
export const messageQueue = new Queue('messages', {
  connection,
  defaultJobOptions: {
    removeOnComplete: { count: 1000 },
    removeOnFail: { count: 5000 },
    attempts: 3,
    backoff: { type: 'exponential', delay: 2000 },
  },
});

// Fila de envio de mensagens (Z-API)
export const sendQueue = new Queue('send-messages', {
  connection,
  defaultJobOptions: {
    removeOnComplete: { count: 1000 },
    removeOnFail: { count: 5000 },
    attempts: 3,
    backoff: { type: 'exponential', delay: 1000 },
  },
});

// Fila de processamento de mídia
export const mediaQueue = new Queue('media', {
  connection,
  defaultJobOptions: {
    removeOnComplete: { count: 500 },
    removeOnFail: { count: 1000 },
    attempts: 2,
  },
});

export { connection };
