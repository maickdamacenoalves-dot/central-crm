# Central de Tintas — CRM Conversacional

Sistema de atendimento via WhatsApp com IA, integração VHSYS e painel de gestão.

## Stack

- **Backend**: Node.js + Fastify + BullMQ
- **Banco**: PostgreSQL 16 + Redis 7
- **ORM**: Prisma
- **WhatsApp**: Z-API
- **IA**: Claude API (Anthropic)
- **ERP**: VHSYS API V2

## Setup Rápido

### 1. Clone e configure

```bash
git clone https://github.com/maickdamacenoalves-dot/central-crm.git
cd central-crm
cp .env.example .env
# Edite o .env com suas credenciais
```

### 2. Suba os containers

```bash
docker compose up -d postgres redis
```

### 3. Instale dependências e configure banco

```bash
npm install
npx prisma generate
npx prisma db push
npm run db:seed
```

### 4. Rode o servidor

```bash
npm run dev
```

O servidor inicia em `http://localhost:3333`.

### 5. Configure o webhook na Z-API

Na dashboard da Z-API, configure:
- **Webhook URL**: `https://seu-dominio.com/webhook/zapi`
- **Status URL**: `https://seu-dominio.com/webhook/zapi/status`

## Endpoints

| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/health` | Status do servidor |
| POST | `/webhook/zapi` | Webhook da Z-API |
| POST | `/webhook/webchat` | Webhook do webchat |
| POST | `/auth/login` | Login do atendente |
| POST | `/auth/refresh` | Renovar token |
| GET | `/auth/me` | Perfil do atendente |
| POST | `/auth/logout` | Logout |

## Login de Teste

```
Email: maick@centraldetintas.com
Senha: admin123
```

## Estrutura

```
src/
├── server.js              # Entry point
├── config/
│   ├── env.js             # Variáveis de ambiente
│   ├── redis.js           # Conexão Redis
│   └── database.js        # Prisma Client
├── routes/
│   ├── webhook.js         # Z-API + Webchat webhooks
│   ├── auth.js            # Login, refresh, logout
│   └── health.js          # Health check
├── services/
│   ├── message-router.js  # Roteamento + carteirização
│   ├── zapi.js            # Envio de mensagens WhatsApp
│   └── session.js         # Gestão de sessões e contatos
├── queues/
│   ├── setup.js           # Filas BullMQ
│   └── workers/
│       └── message-worker.js
├── middleware/
│   └── auth.js            # JWT + RBAC
└── utils/
    ├── crypto.js          # AES-256-GCM
    └── logger.js          # Pino logger
```

## Fases do Projeto

- [x] **Fase 1**: Fundação (Docker, DB, Auth, Webhook, Router)
- [ ] **Fase 2**: IA + Carteirização (Claude, botões de loja, fast path)
- [ ] **Fase 3**: Painel + Mídia + VHSYS
- [ ] **Fase 4**: Segurança + Backup + Deploy
