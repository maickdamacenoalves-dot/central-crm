import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando seed...');

  // =============================================
  // Organização
  // =============================================
  const org = await prisma.organization.upsert({
    where: { slug: 'central-de-tintas' },
    update: {},
    create: {
      id: 'org-central-tintas',
      name: 'Grupo Central de Tintas',
      slug: 'central-de-tintas',
      plan: 'ENTERPRISE',
      settings: {
        timezone: 'America/Sao_Paulo',
        businessHours: { start: '08:00', end: '18:00' },
        workDays: ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'],
      },
    },
  });
  console.log(`✅ Organização: ${org.name}`);

  // =============================================
  // Lojas
  // =============================================
  const storesData = [
    {
      id: 'store-garopaba',
      name: 'SC Distribuidora Garopaba',
      phone: '(48) 3254-0001',
      city: 'Garopaba',
      state: 'SC',
      businessHours: {
        weekdays: { open: '08:00', close: '18:00' },
        saturday: { open: '08:00', close: '12:00' },
        sunday: null,
      },
    },
    {
      id: 'store-imbituba',
      name: 'SC Distribuidora Imbituba',
      phone: '(48) 3255-0002',
      city: 'Imbituba',
      state: 'SC',
      businessHours: {
        weekdays: { open: '08:00', close: '18:00' },
        saturday: { open: '08:00', close: '12:00' },
        sunday: null,
      },
    },
    {
      id: 'store-laguna',
      name: 'SC Distribuidora Laguna',
      phone: '(48) 3644-0003',
      city: 'Laguna',
      state: 'SC',
      businessHours: {
        weekdays: { open: '08:00', close: '18:00' },
        saturday: { open: '08:00', close: '12:00' },
        sunday: null,
      },
    },
    {
      id: 'store-sw-garopaba',
      name: 'Sherwin Williams Garopaba',
      phone: '(48) 3254-0004',
      city: 'Garopaba',
      state: 'SC',
      businessHours: {
        weekdays: { open: '08:00', close: '18:00' },
        saturday: { open: '08:00', close: '12:00' },
        sunday: null,
      },
    },
    {
      id: 'store-garopaba-tintas',
      name: 'Garopaba Tintas',
      phone: '(48) 3254-0005',
      city: 'Garopaba',
      state: 'SC',
      businessHours: {
        weekdays: { open: '08:00', close: '18:00' },
        saturday: { open: '08:00', close: '12:00' },
        sunday: null,
      },
    },
  ];

  for (const storeData of storesData) {
    const store = await prisma.store.upsert({
      where: { id: storeData.id },
      update: {},
      create: {
        ...storeData,
        orgId: org.id,
      },
    });
    console.log(`  🏪 Loja: ${store.name}`);
  }

  // =============================================
  // Admin (Super Admin)
  // =============================================
  const adminPassword = await bcrypt.hash('admin123', 12);

  const admin = await prisma.agent.upsert({
    where: { email: 'maick@centraldetintas.com' },
    update: {},
    create: {
      name: 'Maick Alves',
      email: 'maick@centraldetintas.com',
      passwordHash: adminPassword,
      role: 'SUPER_ADMIN',
      storeId: 'store-garopaba-tintas',
      maxConcurrent: 10,
    },
  });
  console.log(`  👑 Super Admin: ${admin.name} (${admin.email})`);

  // =============================================
  // Atendentes de teste
  // =============================================
  const agentPassword = await bcrypt.hash('atendente123', 12);

  const agentsData = [
    { name: 'Rafael Silva', email: 'rafael@centraldetintas.com', storeId: 'store-garopaba' },
    { name: 'Camila Santos', email: 'camila@centraldetintas.com', storeId: 'store-garopaba' },
    { name: 'Juliana Costa', email: 'juliana@centraldetintas.com', storeId: 'store-imbituba' },
    { name: 'Marcos Oliveira', email: 'marcos@centraldetintas.com', storeId: 'store-imbituba' },
    { name: 'Fernanda Lima', email: 'fernanda@centraldetintas.com', storeId: 'store-laguna' },
    { name: 'Patricia Souza', email: 'patricia@centraldetintas.com', storeId: 'store-sw-garopaba' },
    { name: 'Amanda Rocha', email: 'amanda@centraldetintas.com', storeId: 'store-garopaba-tintas' },
    { name: 'Thiago Mendes', email: 'thiago@centraldetintas.com', storeId: 'store-garopaba-tintas' },
  ];

  for (const agentData of agentsData) {
    const agent = await prisma.agent.upsert({
      where: { email: agentData.email },
      update: {},
      create: {
        ...agentData,
        passwordHash: agentPassword,
        role: 'AGENT',
      },
    });
    console.log(`  👤 Atendente: ${agent.name} → ${agentData.storeId.replace('store-', '')}`);
  }

  console.log('\n✅ Seed concluído!');
  console.log('───────────────────────────');
  console.log('Login admin:');
  console.log('  Email: maick@centraldetintas.com');
  console.log('  Senha: admin123');
  console.log('───────────────────────────');
}

main()
  .catch((e) => {
    console.error('❌ Erro no seed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
